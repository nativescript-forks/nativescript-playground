export declare class Threads {
}
