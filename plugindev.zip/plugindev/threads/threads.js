"use strict";
var Threads = (function () {
    function Threads() {
    }
    return Threads;
}());
exports.Threads = Threads;
