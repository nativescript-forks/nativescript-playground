﻿import "./dev/tns.console"
import * as app from 'application';
app.start({ moduleName: 'main-page' });
