"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var lodash_1 = require("lodash");
var Promise = require("bluebird");
var application = require("application");
var observable_1 = require("data/observable");
var observable_array_1 = require("data/observable-array");
var image_source_1 = require("image-source");
function onLoaded(args) {
    var page = args.object;
    page.bindingContext = new Index();
}
exports.onLoaded = onLoaded;
var Index = (function (_super) {
    __extends(Index, _super);
    function Index() {
        _super.call(this);
        this.items = new observable_array_1.ObservableArray([]);
    }
    Index.parseAsyncResults = function (json, predicate) {
        var i, len = json.length;
        for (i = 0; i < len; i++) {
            var sendi = {};
            var item = json[i];
            var ii = void 0, len_1 = item.length;
            for (ii = 0; ii < len_1; ii += 2) {
                sendi[item[ii]] = item[ii + 1];
            }
            json[i] = sendi;
        }
        if (predicate) {
            lodash_1.remove(json, function (item) {
                return item[predicate] == null;
            });
        }
    };
    Index.prototype.pickContact = function () {
        this.items.splice(0, this.items.length);
    };
    Index.prototype.doit = function () {
        var _this = this;
        global.tnsconsole.info('DOIT');
        console.time('DOIT');
        return this.getConversations().then(function (results) {
            var proms = [];
            var i, len = results.length;
            for (i = 0; i < len; i++) {
                proms.push(_this.mergeContactData(results[i]));
            }
            return Promise.each(proms, function (item) {
                global.tnsconsole.log('Promise.each > item', item);
                _this.items.push(item);
            });
        }).then(function (results) {
            global.tnsconsole.warn('DONE');
            console.timeEnd('DOIT');
        }).catch(function (error) {
            global.tnsconsole.error('error', error);
        });
    };
    Index.prototype.getConversations = function () {
        return new Promise(function (resolve, reject) {
            var projection = [
                android.provider.Telephony.TextBasedSmsColumns.THREAD_ID,
                android.provider.Telephony.TextBasedSmsColumns.ADDRESS,
                android.provider.Telephony.TextBasedSmsColumns.DATE,
                android.provider.Telephony.TextBasedSmsColumns.BODY,
            ];
            com.roblav96.threads.Threads.getAsyncContentProvider(application.android.context, android.provider.Telephony.MmsSms.CONTENT_CONVERSATIONS_URI, projection, null, null, android.provider.Telephony.TextBasedSmsColumns.DATE + ' DESC', false).continueWith(new bolts.Continuation({
                then: function (task) {
                    setTimeout(function () {
                        try {
                            if (task.isCancelled()) {
                                return reject('task.isCancelled()');
                            }
                            else if (task.isFaulted()) {
                                var error = task.getError();
                                return reject(error.getMessage());
                            }
                            else {
                                var json = JSON.parse(task.getResult());
                                Index.parseAsyncResults(json, 'address');
                                return resolve(json);
                            }
                        }
                        catch (error) {
                            return reject(error);
                        }
                    }, 0);
                }
            }));
        });
    };
    Index.prototype.mergeContactData = function (item) {
        return new Promise(function (resolve, reject) {
            var projection = [
                android.provider.Telephony.TextBasedSmsColumns.PERSON,
                android.provider.Telephony.TextBasedSmsColumns.DATE_SENT,
            ];
            com.roblav96.threads.Threads.getAsyncContentProvider(application.android.context, android.provider.Telephony.Sms.Inbox.CONTENT_URI, projection, android.provider.Telephony.TextBasedSmsColumns.THREAD_ID + ' = ' + item.thread_id, null, null, true).continueWith(new bolts.Continuation({
                then: function (task) {
                    setTimeout(function () {
                        try {
                            if (task.isCancelled()) {
                                return reject('task.isCancelled()');
                            }
                            else if (task.isFaulted()) {
                                var error = task.getError();
                                return reject(error.getMessage());
                            }
                            else {
                                var json = JSON.parse(task.getResult());
                                Index.parseAsyncResults(json);
                                lodash_1.merge(item, json[0]);
                                return resolve(item);
                            }
                        }
                        catch (error) {
                            return reject(error);
                        }
                    }, 0);
                }
            }));
        }).then(function (item) {
            if (typeof item.person != 'string') {
                return Promise.resolve(item);
            }
            return new Promise(function (resolve, reject) {
                var projection = [
                    android.provider.ContactsContract.ContactsColumns.DISPLAY_NAME,
                    android.provider.ContactsContract.ContactsColumns.PHOTO_URI,
                    android.provider.ContactsContract.ContactsColumns.CONTACT_LAST_UPDATED_TIMESTAMP,
                ];
                com.roblav96.threads.Threads.getAsyncContentProvider(application.android.context, android.provider.ContactsContract.Data.CONTENT_URI, projection, android.provider.ContactsContract.DataColumns.RAW_CONTACT_ID + ' = ' + item.person, null, null, true).continueWith(new bolts.Continuation({
                    then: function (task) {
                        setTimeout(function () {
                            try {
                                if (task.isCancelled()) {
                                    return reject('task.isCancelled()');
                                }
                                else if (task.isFaulted()) {
                                    var error = task.getError();
                                    return reject(error.getMessage());
                                }
                                else {
                                    var json = JSON.parse(task.getResult());
                                    Index.parseAsyncResults(json);
                                    lodash_1.merge(item, json[0]);
                                    return resolve(item);
                                }
                            }
                            catch (error) {
                                return reject(error);
                            }
                        }, 0);
                    }
                }));
            });
        }).then(function (item) {
            if (item.photo_uri) {
                var bitmap = android.provider.MediaStore.Images.Media.getBitmap(application.android.foregroundActivity.getContentResolver(), android.net.Uri.parse(item.photo_uri));
                var width = bitmap.getWidth();
                var height = bitmap.getHeight();
                var output = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888);
                var canvas = new android.graphics.Canvas(output);
                var color = android.graphics.Color.RED;
                var paint = new android.graphics.Paint();
                var rect = new android.graphics.Rect(0, 0, width, height);
                var rectF = new android.graphics.RectF(rect);
                paint.setAntiAlias(true);
                canvas.drawARGB(0, 0, 0, 0);
                paint.setColor(color);
                canvas.drawOval(rectF, paint);
                paint.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SRC_IN));
                canvas.drawBitmap(bitmap, rect, rect, paint);
                bitmap.recycle();
                item.photo = image_source_1.fromNativeSource(output);
            }
            else {
                item.photo = image_source_1.fromResource('icon');
            }
            return Promise.resolve(item);
        });
    };
    Index.prototype.getContacts = function () {
        return new Promise(function (resolve, reject) {
            var projection = [
                android.provider.ContactsContract.RawContactsColumns.CONTACT_ID,
                android.provider.ContactsContract.ContactsColumns.DISPLAY_NAME,
                android.provider.ContactsContract.ContactsColumns.HAS_PHONE_NUMBER,
                android.provider.ContactsContract.ContactsColumns.LOOKUP_KEY,
                android.provider.ContactsContract.ContactsColumns.PHOTO_URI,
                android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER,
                android.provider.ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER,
                android.provider.ContactsContract.CommonDataKinds.CommonColumns.TYPE,
                android.provider.ContactsContract.DataColumns.MIMETYPE,
            ];
            com.roblav96.threads.Threads.getAsyncContentProvider(application.android.context, android.provider.ContactsContract.Data.CONTENT_URI, projection, android.provider.ContactsContract.ContactsColumns.HAS_PHONE_NUMBER + " = 1", null, null, false).continueWith(new bolts.Continuation({
                then: function (task) {
                    setTimeout(function () {
                        try {
                            if (task.isCancelled()) {
                                return reject('task.isCancelled()');
                            }
                            else if (task.isFaulted()) {
                                var error = task.getError();
                                return reject(error.getMessage());
                            }
                            else {
                                var json = JSON.parse(task.getResult());
                                return resolve(json);
                            }
                        }
                        catch (error) {
                            return reject(error);
                        }
                    }, 0);
                }
            }));
        });
    };
    return Index;
}(observable_1.Observable));
function getJsonFromCursor(cursor) {
    function getCursorValue(cursor, i) {
        var type = cursor.getType(i);
        if (type == android.database.Cursor.FIELD_TYPE_INTEGER) {
            return cursor.getLong(i);
        }
        else if (type == android.database.Cursor.FIELD_TYPE_FLOAT) {
            return cursor.getFloat(i);
        }
        else if (type == android.database.Cursor.FIELD_TYPE_STRING) {
            return cursor.getString(i);
        }
        else if (type == android.database.Cursor.FIELD_TYPE_BLOB) {
            return cursor.getBlob(i);
        }
        else {
            return null;
        }
    }
    var json = {};
    var keys = cursor.getColumnNames();
    var i, len = cursor.getColumnCount();
    for (i = 0; i < len; i++) {
        var value = getCursorValue(cursor, i);
        if (value != null) {
            json[keys[i]] = value;
        }
    }
    return json;
}
