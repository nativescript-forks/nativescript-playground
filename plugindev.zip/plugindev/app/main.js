"use strict";
require("./dev/tns.console");
var app = require('application');
app.start({ moduleName: 'main-page' });
